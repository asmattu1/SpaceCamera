Enclosure directory.
====================

 
For any 3D files/models of enclosures that are included with products. 
For example, the casing for the MicroView.  

